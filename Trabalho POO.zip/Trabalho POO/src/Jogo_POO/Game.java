package Jogo_POO;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Game extends JPanel{

	Frame f;
	Game g;
	
	JPanel layerPopUp;
	JPanel popUp;
	JLabel descPoints;
	JLabel again;
	
	public JPanel header;
	public JLabel title;
	public JLabel heart[] = new JLabel[5];
	
	public JPanel content;
	
	public int life = 5;
	Timer timer;
	int point = 0;
	
	public Game(Frame f) {
		
		this.f = f;
		this.g = this;
		
		setLayout(null);
		setSize(f.main.getSize());
		setOpaque(false);
		f.main.add(this);
		
		//popUp creation
		layerPopUp = new JPanel();
		layerPopUp.setLayout(null);
		layerPopUp.setSize(getSize());
		layerPopUp.setBackground(new Color(0,0,0,50));
		layerPopUp.setVisible(false);
		add(layerPopUp);
		
		popUp = new JPanel();
		popUp.setLayout(null);
		popUp.setBounds((layerPopUp.getWidth()/2)-150, (layerPopUp.getHeight()/2)-150, 300, 300);
		popUp.setBackground(new Color(255,255,255));
		layerPopUp.add(popUp);
		
		descPoints = new JLabel();
		descPoints.setBounds(10, 40, popUp.getWidth()-20, 100);
		descPoints.setFont(new Font("Arial",  Font. BOLD,  35));
		descPoints.setForeground(new Color(111,172,167));
		descPoints.setHorizontalAlignment(SwingConstants.CENTER);
		descPoints.setVerticalAlignment(SwingConstants.CENTER);
		popUp.add(descPoints);
		
		again = new JLabel("Play again");
		again.setBounds(10, 200, popUp.getWidth()-20, 100);
		again.setFont(new Font("Arial",  Font. BOLD,  20));
		again.setForeground(new Color(173,211,162));
		again.setHorizontalAlignment(SwingConstants.CENTER);
		again.setVerticalAlignment(SwingConstants.CENTER);
		again.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {}
			
			@Override
			public void mousePressed(MouseEvent arg0) {}
			
			@Override
			public void mouseExited(MouseEvent arg0) {}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {}
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				f.main.removeAll();
				f.repaint();
				new Game(f);
				
			}
		});
		popUp.add(again);
		//popUp finish
		
		header = new JPanel();
		header.setLayout(null);
		header.setSize(getWidth(), 70);
		header.setBackground(new Color(0,0,0,20));
		add(header);
		
		title = new JLabel("Pontos: "+point);
		title.setBounds(10, 0, header.getWidth(), header.getHeight());
		title.setFont(new Font("Arial",  Font. BOLD,  25));
		title.setForeground(new Color(255,255,255));
		title.setHorizontalAlignment(SwingConstants.LEFT);
		title.setVerticalAlignment(SwingConstants.CENTER);
		header.add(title);
		
		for(int i=0; i<heart.length; i++) {
			
			heart[i] = new JLabel(new javax.swing.ImageIcon(getClass().getResource("/img/heart.png")));
			heart[i].setSize(30,30);
			
			if(i==0)
				heart[i].setLocation(315, 20);
			else
				heart[i].setLocation(heart[i-1].getX()+heart[i-1].getWidth()+5, heart[i-1].getY());
			
			header.add(heart[i]);
			
		}
		
		content = new JPanel();
		content.setLayout(null);
		content.setBounds(0, header.getHeight(), getWidth(), getHeight()-header.getHeight());
		content.setOpaque(false);
		add(content);
	
		time();
		
	}
	
	public void time() {
		
		timer = new Timer();
		
		timer.scheduleAtFixedRate(new TimerTask(){
			
			public void run(){
				
				new Box(g);
				
				point++;
				title.setText("Pontos: "+point);
				f.repaint();
					
			}
					
		},1000,1000);
		
	}
	
	public void finish() {
		
		if(life == 0) {
			
			timer.cancel();
			descPoints.setText("Pontos: "+point);
			layerPopUp.setVisible(true);
			
		}
		
	}
	
}
