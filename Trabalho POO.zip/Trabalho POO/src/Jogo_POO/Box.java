package Jogo_POO;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class Box extends JLabel{

	Game g;
	Timer timer;
	int index;
	
	Color[] colors = {new Color(20,20,20), 
					  new Color(69,141,224), 
					  new Color(171,123,241), 
					  new Color(255,203,47), 
					  new Color(249,132,6), 
					  new Color(253,66,62)};
	
	Color[] border = {new Color(80,80,80), 
					  new Color(58,122,196), 
					  new Color(148,109,206), 
					  new Color(233,186,46), 
					  new Color(212,103,7), 
					  new Color(195, 61, 58)};
	
	int[] speed = {100, 50, 100, 150, 200, 300};
	int currentSpeed = 0;
	
	public Box(Game g) {
		
		this.g = g;
		
		Random r = new Random();
		
		int position = 5 + r.nextInt(g.content.getWidth()-85);
		
		index = r.nextInt(6);
		
		currentSpeed = speed[index];
		
		if(index == 0) {
			setText("TNT");
			setFont(new Font("Arial",  Font. BOLD,  30));
		}else {
			setText(""+index);
			setFont(new Font("Arial",  Font. BOLD,  40));
		}
			
		setSize(80,80);
		setOpaque(true);
		setBackground(colors[index]);
		setBorder(new LineBorder(border[index], 4, false));
		setForeground(new Color(255,255,255));
		setHorizontalAlignment(SwingConstants.CENTER);
		setVerticalAlignment(SwingConstants.CENTER);
		setLocation(position,0);
		g.content.add(this);
		addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {}
			
			@Override
			public void mousePressed(MouseEvent arg0) {}
			
			@Override
			public void mouseExited(MouseEvent arg0) {}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				index--;
				
				if(index == 0) {
					timer.cancel();
					((JLabel)e.getSource()).setVisible(false);
				}else if(index == -1) {
					timer.cancel();
					((JLabel)e.getSource()).setVisible(false);
					g.heart[g.life-1].setVisible(false);
					g.life--;
					g.f.repaint();
					g.finish();
				}else {
					((JLabel)e.getSource()).setText(""+index);
					((JLabel)e.getSource()).setBackground(colors[index]);
					((JLabel)e.getSource()).setBorder(new LineBorder(border[index], 4, false));
					currentSpeed = speed[index];
				}
				
				
			}
		});
		
		time(this);
		
	}
	
	public void time(Box b) {
		
		timer = new Timer();
		
		timer.scheduleAtFixedRate(new TimerTask(){
			
			public void run(){
				
				if(g.life > 0) {
				
					b.setLocation(b.getX(), b.getY()+5);
					
					if(b.getY() > g.content.getHeight() && index > 0) {
						timer.cancel();
						g.heart[g.life-1].setVisible(false);
						g.life--;
						g.f.repaint();
						g.finish();
					}
					
				}
				
				
			}
					
		},currentSpeed, currentSpeed);
		
	}
	
}
