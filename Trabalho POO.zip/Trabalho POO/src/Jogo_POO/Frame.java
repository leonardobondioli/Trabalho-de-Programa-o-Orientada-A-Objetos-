package Jogo_POO;

import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class Frame extends JFrame{

	JLabel background;
	
	public JPanel main;
	
	public Frame() {
		
		//jframe creation
		setLayout(null);
		setSize(500, 700);
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    getContentPane().setBackground(new Color(255, 255, 255));
	    setUndecorated(true);
	    setLocationRelativeTo( null );
	    
		main = new JPanel();
		main.setLayout(null);
		main.setBounds(6, 6, getWidth()-12, getHeight()-12);
		main.setOpaque(false);
		add(main);
	    
		
		background = new JLabel(new javax.swing.ImageIcon(getClass().getResource("/img/background.jpg")));
		background.setSize(getSize());
		background.setOpaque(true);
		background.setBorder(new LineBorder(new Color(68,173,168), 6, false));
		add(background);
			
		
	    new Start(this);
	    
	    setVisible(true);
		
	}
	
}
