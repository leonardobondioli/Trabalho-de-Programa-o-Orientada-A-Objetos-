package Jogo_POO;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

public class Start extends JPanel{

	Frame f;
	Start s;
	
	JPanel header;
	JLabel title;
	JLabel play;
	
	public Start(Frame f) {
		
		this.f = f;
		this.s = this;
		
		setLayout(null);
		setSize(f.main.getSize());
		setOpaque(false);
		f.main.add(this);
		
		header = new JPanel();
		header.setLayout(null);
		header.setSize(getWidth(), 70);
		header.setBackground(new Color(0,0,0,20));
		add(header);
		
		title = new JLabel("Jogo dos Cliques!");
		title.setSize(header.getSize());
		title.setFont(new Font("Arial",  Font. BOLD,  45));
		title.setForeground(new Color(255,255,255));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setVerticalAlignment(SwingConstants.CENTER);
		header.add(title);
		
		play = new JLabel(new javax.swing.ImageIcon(getClass().getResource("/img/play.png")));
		play.setBounds((getWidth()/2)-75, (getHeight()/2)-75, 150, 150);
		play.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		play.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent arg0) {}
			
			@Override
			public void mousePressed(MouseEvent arg0) {}
			
			@Override
			public void mouseExited(MouseEvent arg0) {}
			
			@Override
			public void mouseEntered(MouseEvent arg0) {}
			
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				f.remove(s);
				s.setVisible(false);
				new Game(f);
				f.repaint();
				
			}
		});
		add(play);
		
	}
	
}
